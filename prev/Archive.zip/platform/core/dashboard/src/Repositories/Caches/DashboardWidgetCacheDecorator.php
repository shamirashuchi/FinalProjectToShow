<?php

namespace Botble\Dashboard\Repositories\Caches;

use Botble\Dashboard\Repositories\Interfaces\DashboardWidgetInterface;
use Botble\Support\Repositories\Caches\CacheAbstractDecorator;

class DashboardWidgetCacheDecorator extends CacheAbstractDecorator implements DashboardWidgetInterface
{
}
