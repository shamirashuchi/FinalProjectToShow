<div class="text-start">
    <div class="checkbox checkbox-primary table-checkbox">
        <input type="checkbox" class="checkboxes" name="id[]" value="{{ $id }}"/>
    </div>
</div>
