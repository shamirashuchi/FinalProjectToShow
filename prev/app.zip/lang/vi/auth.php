<?php

return [
    'failed' => 'Không tìm thấy thông tin đăng nhập hợp lệ.',
    'throttle' => 'Đăng nhập không đúng quá nhiều lần. Vui lòng thử lại sau :seconds giây.',
    'password' => 'Mật khẩu không chính xác',
];
